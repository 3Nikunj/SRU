class Sample:
    def func1(self):
        print("inside func1 of Sample")


class Sample1 (Sample):
    def _func1(self):
        print("inside func2 of Sample1")


s1 = Sample1()
s1.func1()
